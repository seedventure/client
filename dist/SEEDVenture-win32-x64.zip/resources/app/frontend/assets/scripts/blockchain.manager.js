function BlockchainManager() {
    var context = this;
    context.provider = new BlockchainProvider();
};