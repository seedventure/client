function BlockchainProvider() {
    var context = this;

};