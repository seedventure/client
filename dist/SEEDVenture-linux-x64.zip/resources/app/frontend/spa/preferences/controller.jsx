var PreferencesController = function(view) {
    var context = this;
    context.view = view;
}