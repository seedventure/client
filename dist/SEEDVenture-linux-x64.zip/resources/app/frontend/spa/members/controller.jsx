var MembersController = function(view) {
    var context = this;
    context.view = view;
};